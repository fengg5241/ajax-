package com.imooc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AjaxclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(AjaxclientApplication.class, args);
	}
}
